public class ShootingRound{
    int targets;

    public ShootingRound(int targets) {
        this.targets = targets;
    }
    public int getTargets(){
        return targets;
    }
}
