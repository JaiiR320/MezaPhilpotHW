public interface IEvent {
    double pointsEarned();
    double getPenalties();
}
