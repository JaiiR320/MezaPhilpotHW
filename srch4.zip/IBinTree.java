interface IBinTree {
    // determines whether element is in the tree
    boolean hasElt(int e);
    // returns number of nodes in the tree; counts duplicate elements as separate items
    int size();
    // returns depth of longest branch in the tree
    int height();

    public int countElt();

    public boolean isSmaller(int data);

    // Checks if the Bt is a heap
    public boolean isHeap();

    /**
     * Counts the number of occurences of a certain element
     * @param e the element
     * @return the number of times the element appears
     */
    public int occurs(int e);

    /**
     * Checks if the new tree contains all the elements of the old tree, and including the new element
     * @param orig original tree
     * @param e added element
     * @param added new tree with added element
     * @return true if the trees contain the same elements, excluding the new element, false otherwise
     */
    public boolean containsAll(IHeap orig, int e, IBinTree added);

    /**
     * Makes sure that the minimum value was removed from the original tree
     * @param removed the new tree with the removed element
     * @return true if the tree contains 1 less occurence of the element, false otherwise
     */
    public boolean minRemoved(IBinTree removed);

    /**
     * @return the smallest element of the tree
     */
    public int smallestEle();

    /**
     * Checks if the new tree contains the same elements as the original, -1 instance of the removed element
     * @param orig the orignal tree
     * @param added the new tree with -1 occurence of the orig.data
     * @return true if contains 1 less occurence while containing the same elements, false otherwise
     */
    public boolean containsExcept(IHeap orig, IBinTree added);

}