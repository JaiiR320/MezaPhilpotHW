class MtBT implements IBinTree {
    MtBT(){}

    // returns false since empty tree has no elements
    public boolean hasElt(int e) {
        return false;
    }

    // returns 0 since enpty tree has no elements
    public int size() {
        return 0;
    }

    // returns 0 since empty tree has no branches
    public int height() {
        return 0;
    }
    
    // returns 0 since it is not an element
    public int countElt(){
        return 0;
    }

    // always smaller than other elements
    public boolean isSmaller(int data){
        return true;
    }

    // is a heap
    public boolean isHeap(){
        return true;
    }

    // returns 0 because it is not e
    public int occurs(int e){
        return 0;
    }

    // returns true because it went through all other elements
    public boolean containsAll(IHeap orig, int e, IBinTree added){
        return true;
    }

    // returns true because it went through all other elements    
    public boolean containsExcept(IHeap orig, IBinTree added){
        return true;
    }

    // returns true because it went through all other elements
    public boolean minRemoved(IBinTree removed) {
        return true;
    }

    //returns 0 because it has no size
    public int smallestEle() {
        return 0;
    }
}