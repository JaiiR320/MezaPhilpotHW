class DataBT implements IBinTree {
    int data;
    IBinTree left;
    IBinTree right;

    DataBT(int data, IBinTree left, IBinTree right) {
        this.data = data;
        this.left = left;
        this.right = right;
    }
 
    // an alternate constructor for when both subtrees are empty
    DataBT(int data) {
        this.data = data;
        this.left = new MtBT();
        this.right = new MtBT();
    }

    // determines whether this node or node in subtree has given element
    public boolean hasElt(int e) {
        return this.data == e || this.left.hasElt(e) || this.right.hasElt(e) ;
    }

    // adds 1 to the number of nodes in the left and right subtrees
    public int size() {
        return 1 + this.left.size() + this.right.size();
    }

    // adds 1 to the height of the taller subtree
    public int height() {
        return 1 + Math.max(this.left.height(), this.right.height());
    }

    // counts the number of elements in a Binary tree
    public int countElt(){
        return 1 + this.left.countElt() + this.right.countElt();
    }

    // checks to see if heap is valid
    public boolean isSmaller(int e) {
        return e <= data && this.left.isSmaller(data) && this.right.isSmaller(data);
    }

    // Checks if the Bt is a heap
    public boolean isHeap(){
        return this.left.isSmaller(data) && this.right.isSmaller(data);
    }

    /**
     * Counts the number of occurences of a certain element
     * @param e the element
     * @return the number of times the element appears
     */
    public int occurs(int e){
        if (this.data == e) {
            return 1 + this.left.occurs(e) + this.right.occurs(e);
        } else {
            return this.left.occurs(e) + this.right.occurs(e);
        }
    }

    /**
     * Makes sure that the added element is correctly added
     * @param orig original tree 
     * @param e added element
     * @param added new tree
     * @return true if the new tree contains the element, false if not
     */
    public boolean allAccountedFor(IHeap orig, int e, IBinTree added){
        int o = orig.occurs(e);
        int a = added.occurs(e);
        if (a == o+1) {
            return true;
        }
        return false;
    }

    /**
     * Checks if the new tree contains all the elements of the old tree, and including the new element
     * @param orig original tree
     * @param e added element
     * @param added new tree with added element
     * @return true if the trees contain the same elements, excluding the new element, false otherwise
     */
    public boolean containsAll(IHeap orig, int e, IBinTree added){
        int a, o;
        if (this.data == e) {
            o = orig.occurs(this.data);
            a = added.occurs(this.data)-1;
        } else {
            o = orig.occurs(this.data);
            a = added.occurs(this.data);
        }
        if (a == o) {
            return this.left.containsAll(orig, e, added) && this.right.containsAll(orig, e, added);
        }
        return false;
    }

    /**
     * Makes sure that the minimum value was removed from the original tree
     * @param removed the new tree with the removed element
     * @return true if the tree contains 1 less occurence of the element, false otherwise
     */
    public boolean minRemoved(IBinTree removed){
        if (removed.occurs(this.data) == this.occurs(this.data)-1) {
            return true;
        }
        return false;
    }

    /**
     * @return the smallest element of the tree
     */
    public int smallestEle(){
        return this.data;
    }
    
    /**
     * Checks if the new tree contains the same elements as the original, -1 instance of the removed element
     * @param orig the orignal tree
     * @param added the new tree with -1 occurence of the orig.data
     * @return true if contains 1 less occurence while containing the same elements, false otherwise
     */
    public boolean containsExcept(IHeap orig, IBinTree added){
        int a, o;
        if (this.data == orig.smallestEle()) {
            o = orig.occurs(this.data)-1;
            a = added.occurs(this.data);
        } else {
            o = orig.occurs(this.data);
            a = added.occurs(this.data);
        }
        if (a == o) {
            return this.left.containsExcept(orig, added) && this.right.containsExcept(orig, added);
        }
        return false;
    }
}