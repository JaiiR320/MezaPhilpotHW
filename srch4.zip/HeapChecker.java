public class HeapChecker {

    /**
     * Makes sure the element was properly added to the tree. hAdded be a heap
     * @param hOrig the orignal tree
     * @param elt the added element
     * @param hRemoved the new tree with +1 occurence of elt
     * @return true if properly added, false if not
     */
    public boolean addEltTester(IHeap hOrig, int elt, IBinTree hAdded){
        return hAdded.isHeap() && hOrig.isHeap() && hAdded.hasElt(elt) && hOrig.containsAll(hOrig, elt, hAdded) && (hOrig.size() == hAdded.size()-1);
    }

    /**
     * Makes sure the minimum element was properly removed from the tree. hRemoved should be a heap
     * @param hOrig the orignal tree
     * @param hRemoved the new tree with -1 occurence of orig.data
     * @return true if properly removed, false if not
     */
    public boolean remMinEltTester(IHeap hOrig, IBinTree hRemoved) {
        if ((hOrig.size() == 0) && (hRemoved.size() == 0)) {
            return true;
        }
        return hRemoved.isHeap() && hOrig.isHeap() && hOrig.minRemoved(hRemoved) && hRemoved.containsExcept(hOrig, hRemoved) && (hOrig.size() == hRemoved.size()+1);
    }
}
