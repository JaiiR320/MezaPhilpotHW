import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.util.Random;

import org.junit.Test;

/**
 * Jair Meza 
 * jdmeza 
 * Robert Philpot 
 * rlphilpot 
 * Examples
 */
public class Examples {
    Random r = new Random();
    HeapChecker h = new HeapChecker();

    @Test
    public void addEltTesterTest(){
        DataHeap d = new DataHeap(1, new DataHeap(5, new DataHeap(8), new DataHeap(6)), new DataHeap(10, new DataHeap(15, new MtHeap(), new MtHeap()), new MtHeap()));
        DataHeap invalid = new DataHeap(10, new DataHeap(8), new MtHeap());
        DataHeap da = new DataHeap(1, new DataHeap(5, new DataHeap(8), new DataHeap(10)), new DataHeap(10, new DataHeap(15, new MtHeap(), new MtHeap()), new MtHeap()));
        DataHeap db = new DataHeap(1);

        assertTrue(h.addEltTester(da, 16, da.addElt(16)));
        assertTrue(h.addEltTester(d, 16, d.addElt(16))); // valid heap
        assertFalse(h.addEltTester(d, 16, invalid.addElt(16))); // invalid heap
        assertFalse(h.addEltTester(d, 12, d.addElt(12).addElt(12))); // added wrong num of times + num of elements
        assertFalse(h.addEltTester(d, 12, d.addElt(3).addElt(18))); // incorrect elements + num of elements
        assertTrue(h.addEltTester(db, 13, db.addElt(13)));
    }

    @Test
    public void remMinEltTesterTest(){
        DataHeap d = new DataHeap(1, new DataHeap(5, new DataHeap(8), new DataHeap(6)), new DataHeap(10, new DataHeap(15, new MtHeap(), new MtHeap()), new MtHeap()));
        DataHeap invalid = new DataHeap(10, new DataHeap(8), new MtHeap());
        DataHeap da = new DataHeap(1, new DataHeap(5, new DataHeap(8), new DataHeap(10)), new DataHeap(10, new DataHeap(15, new MtHeap(), new MtHeap()), new MtHeap()));
        DataHeap db = new DataHeap(1);

        assertTrue(h.remMinEltTester(db.remMinElt(), db.remMinElt().remMinElt())); // empty heap input
        assertTrue(h.remMinEltTester(d, d.remMinElt())); // valid heap
        assertFalse(h.remMinEltTester(d, invalid)); // invalid heap
        assertFalse(h.remMinEltTester(d, d.remMinElt().remMinElt())); // added wrong num of times + num of elements
        assertFalse(h.remMinEltTester(d, da.remMinElt())); // incorrect elements + num of elements
        assertFalse(h.remMinEltTester(d, db.remMinElt())); // num of elements

    }
}
