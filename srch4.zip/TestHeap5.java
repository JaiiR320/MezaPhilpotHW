import java.util.Random;

class TestHeap5 extends DataHeap {
    private Random newElt = new Random();
	IHeap left;
	IHeap right;

	TestHeap5(int data, IHeap left, IHeap right) {
		super (data, left, right);
		this.left = left;
		this.right = right;
	}
	
	@Override
	public IHeap addElt(int e) {
		return new TestHeap5 (newElt.nextInt(), this.right, this.left);
	}
}